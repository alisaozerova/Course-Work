using PrivateClinic.Models;
using PrivateClinic.Enums;
using Microsoft.AspNetCore.Identity;

namespace TestData
{
    public class AccountTest
    {
        [Fact]
        public void AccountModel()
        {
            var account = new Account
            {
                UserName = "admin",
                Email = "admin@example.com",
                FirstName = "Admin",
                Name = "Admin",
                LastName = "Admin",
                Type = TypeDoc.GeneralPractitioner,
                Role = TypeRole.Admin,
            };
            Assert.Equal("admin", account.UserName);
            Assert.Equal("admin@example.com", account.Email);
            Assert.Equal("Admin", account.FirstName);
            Assert.Equal("Admin", account.Name);
            Assert.Equal("Admin", account.LastName);
            Assert.Equal(TypeDoc.GeneralPractitioner, account.Type);
            Assert.Equal(TypeRole.Admin, account.Role);
        }
    }
}