using PrivateClinic.Models;
using PrivateClinic.Enums;
using Microsoft.AspNetCore.Identity;

namespace TestData
{
    public class RequestTest
    {
        [Fact]
        public void Test1()
        {
            var request = new Request
            {
                Id = 1,
                Name = "User",
                Description = "Test"
            };
            Assert.Equal(1, request.Id);
            Assert.Equal("User", request.Name);
            Assert.Equal("Test", request.Description);
        }
    }
}