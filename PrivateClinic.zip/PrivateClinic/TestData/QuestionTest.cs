using PrivateClinic.Models;
using PrivateClinic.Enums;
using Microsoft.AspNetCore.Identity;

namespace TestData
{
    public class QuestionTest
    {
        [Fact]
        public void QuestionModel()
        {
            var question = new Question 
            { 
                Id = 1,
                Title = "Test",
                Description = "Test"
            };
            Assert.Equal(1, question.Id);
            Assert.Equal("Test", question.Title);
            Assert.Equal("Test", question.Description);
        }
    }
}