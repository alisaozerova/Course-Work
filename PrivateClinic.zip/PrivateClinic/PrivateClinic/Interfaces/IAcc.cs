﻿namespace PrivateClinic.Interfaces
{
    public interface IAcc
    {
    }
}
