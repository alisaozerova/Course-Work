﻿namespace PrivateClinic.Interfaces
{
    public interface IHome
    {
    }
}
