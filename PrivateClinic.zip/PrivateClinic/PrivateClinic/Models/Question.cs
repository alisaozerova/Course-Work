﻿using System.ComponentModel.DataAnnotations;

namespace PrivateClinic.Models
{
    public class Question
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Заголовок")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Опис")]
        public string Description { get; set; }
    }
}
