﻿using Microsoft.AspNetCore.Identity;
using PrivateClinic.Enums;
namespace PrivateClinic.Models
{
    public class Account : IdentityUser
    {
        public string FirstName { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public TypeDoc Type { get; set; }
        public TypeRole Role { get; set; }
    }
}
