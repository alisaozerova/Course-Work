﻿using PrivateClinic.Enums;
using System.ComponentModel.DataAnnotations;

namespace PrivateClinic.Models
{
    public class Request
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Ім`я")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Опис")]
        public string Description { get; set; }
        public bool Available { get; set; } = true;
        [Display(Name = "Посада")]
        public TypeDoc Type { get; set; }
    }
}
