﻿using PrivateClinic.Enums;
using System.ComponentModel.DataAnnotations;

namespace PrivateClinic.Models
{
    public class ModelAccount
    {
        public string Id { get; set; } = "";
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Фамілія")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Ім`я")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Прізвище")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Логін")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Пошта")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Номер телефона")]
        public string Number { get; set; }
        [Display(Name = "Посада користувача")]
        public TypeDoc Type { get; set; } = 0;
        [Display(Name = "Роль користувача")]
        public TypeRole Role { get; set; } = TypeRole.Doctor;
        [Required(ErrorMessage = "Поле обов`язкове для заповнення!")]
        [Display(Name = "Пароль")]
        public string Password { get; set; }
    }
}
