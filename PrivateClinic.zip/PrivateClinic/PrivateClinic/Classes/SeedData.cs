﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using PrivateClinic.Data;
using PrivateClinic.Enums;
using PrivateClinic.Models;
using System;
using System.Threading.Tasks;

namespace PrivateClinic.Classes
{
    public static class SeedData
    {
        public static async Task Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                var userManager = serviceProvider.GetRequiredService<UserManager<Account>>();
                context.Database.EnsureCreated();
                if (await userManager.FindByNameAsync("admin") == null)
                {
                    var admin = new Account
                    {
                        UserName = "admin",
                        Email = "admin@example.com",
                        FirstName = "Admin",
                        Name = "Admin",
                        LastName = "Admin",
                        Type = TypeDoc.GeneralPractitioner,
                        Role = TypeRole.Admin,
                    };
                    var result = await userManager.CreateAsync(admin, "Admin12345");
                }
            }
        }
    }
}   
