﻿using PrivateClinic.Data;
using PrivateClinic.Models;
using Microsoft.AspNetCore.Identity;
namespace PrivateClinic.Classes
{
    public class FindByType: Finding
    {
        public override List<Request> DoctorsType(Account user, ApplicationDbContext _context)
        {
            List<Request> list = _context.Requests.Where(u => u.Type == user.Type).ToList();
            return list;
        }
        public static List<Question> GetListQuestions(ApplicationDbContext _context)
        {
            List<Question> list = _context.Questions.ToList();
            return list;
        }
        public static List<Account> GetListAccounts(UserManager<Account> _userManager, Account currentuser)
        {
            var users = _userManager.Users.ToList();
            List<Account> list = users.Where(u => u.Id != currentuser.Id).ToList();
            return list;
        }
        public static List<Request> GetListRequests(ApplicationDbContext _context)
        {
            List<Request> list = _context.Requests.ToList();
            return list;
        }
    }
}
