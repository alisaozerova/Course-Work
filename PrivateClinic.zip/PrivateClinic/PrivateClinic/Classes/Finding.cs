﻿using Microsoft.AspNetCore.Identity;
using PrivateClinic.Data;
using PrivateClinic.Models;

namespace PrivateClinic.Classes
{
    public abstract class Finding
    {
        public abstract List<Request> DoctorsType(Account user, ApplicationDbContext _context);
    }
}
