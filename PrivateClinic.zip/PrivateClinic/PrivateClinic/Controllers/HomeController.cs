using Microsoft.AspNetCore.Mvc;
using PrivateClinic.Models;
using System.Diagnostics;
using PrivateClinic.Interfaces;
using PrivateClinic.Data;
using PrivateClinic.Classes;

namespace PrivateClinic.Controllers
{
    public class HomeController : Controller, IHome
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View();
        }
        public async Task<IActionResult> Services()
        {
            return View();
        }
        public async Task<IActionResult> Questions()
        {
            return View(FindByType.GetListQuestions(_context));
        }
        public async Task<IActionResult> SendRequest()
        {
            Request request = new Request();
            return View(request);
        }
        [HttpPost]
        public async Task<IActionResult> SendRequest(Request request)
        {
            if (ModelState.IsValid)
            {
                _context.Requests.Add(request);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(request);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
