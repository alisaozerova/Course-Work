﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PrivateClinic.Classes;
using PrivateClinic.Data;
using PrivateClinic.Interfaces;
using PrivateClinic.Enums;
using PrivateClinic.Models;

namespace PrivateClinic.Controllers
{
    public class AccountController : Controller, IAcc
    {
        private readonly UserManager<Account> _userManager;
        private readonly SignInManager<Account> _signInManager;
        private readonly ApplicationDbContext _context;
        public delegate Task UserEventHandler(string userId, string message);
        public event UserEventHandler UserEventOccurred;
        public AccountController(UserManager<Account> userManager, SignInManager<Account> signInManager, ApplicationDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
            UserEventOccurred += async (userId, message) =>
            {
                TempData["UserNotification"] = message;
            };
        }
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Login()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(ModelLogin model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByNameAsync(model.UserName);
                if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
                {
                    await _signInManager.SignInAsync(user, model.RememberMe);
                    await UserEventOccurred?.Invoke(user.Id, "Успішна авторизація!");
                    return RedirectToAction("Index", "Home");
                }
                ModelState.AddModelError(string.Empty, "Помилка авторизації!");
                return View(model);
            }
            return View(model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> ChangePassword()
        {
            ModelChangePassword model = new ModelChangePassword();
            return View(model);
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ModelChangePassword model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    return RedirectToAction(nameof(Login));
                }

                var changePasswordResult = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);
                if (!changePasswordResult.Succeeded)
                {
                    foreach (var error in changePasswordResult.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                    return View(model);
                }

                await _signInManager.RefreshSignInAsync(user);
                await UserEventOccurred?.Invoke(user.Id, "Успішна зміна пароля!");
                return View(model);
            }
            return View(model);
        }
        [Authorize]
        public async Task<IActionResult> CheckRequests()
        {
            var user = await _userManager.GetUserAsync(User);
            FindByType findByType = new FindByType();
            List<Request> requests = findByType.DoctorsType(user, _context);
            return View(requests);
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> UpdateRequestStatus(int id, bool newAvailable)
        {
            Request request = _context.Requests.FirstOrDefault(r => r.Id == id);
            request.Available = newAvailable;
            await _context.SaveChangesAsync();
            return RedirectToAction("CheckRequests");
        }
        [Authorize]
        public async Task<IActionResult> ManageAccounts()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                return View(FindByType.GetListAccounts(_userManager, user));
            }
            return RedirectToAction("Index", "Home");
        }
        [Authorize]
        public async Task<IActionResult> ManageQuestions()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                return View(FindByType.GetListQuestions(_context));
            }
            return RedirectToAction("Index", "Home");
        }
        [Authorize]
        public async Task<IActionResult> ManageRequests()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                return View(FindByType.GetListRequests(_context));
            }
            return RedirectToAction("Index", "Home");
        }
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> EditAccount(string Id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                var selecteduser = await _userManager.FindByIdAsync(Id);
                if (selecteduser != null)
                {
                    ModelAccount account = new ModelAccount()
                    {
                        Id = selecteduser.Id,
                        FirstName = selecteduser.FirstName,
                        Name = selecteduser.Name,
                        LastName = selecteduser.LastName,
                        UserName = selecteduser.UserName,
                        Email = selecteduser.Email,
                        Number = selecteduser.PhoneNumber,
                        Type = selecteduser.Type,
                        Role = selecteduser.Role,
                        Password = selecteduser.PasswordHash
                    };
                    return View(account);
                }
                return RedirectToAction("ManageAccounts");
            }
            return RedirectToAction("Index", "Home");            
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> EditAccount(ModelAccount account)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                if (ModelState.IsValid)
                {
                    Account acc = await _userManager.FindByIdAsync(account.Id);
                    acc.FirstName = account.FirstName;
                    acc.Name = account.Name;
                    acc.LastName = account.LastName;
                    acc.Email = account.Email;
                    acc.UserName = account.UserName;
                    acc.PhoneNumber = account.Number;
                    acc.Type = account.Type;
                    acc.Role = account.Role;
                    var result = await _userManager.UpdateAsync(acc);
                    if (result.Succeeded)
                    {                        
                        return RedirectToAction("ManageAccounts");
                    }
                }
                return View(account);
            }
            return RedirectToAction("Index", "Home");            
        }
        [Authorize]
        public async Task<IActionResult> EditQuestion(int Id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                var question = await _context.Questions.FindAsync(Id);
                if (question != null)
                    return View(question);
                return RedirectToAction("ManageQuestions");
            }
            return RedirectToAction("Index", "Home");            
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> EditQuestion(Question question)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                if (ModelState.IsValid)
                {
                    _context.Questions.Update(question);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("ManageQuestions");
                }
                return View(question);
            }
            return RedirectToAction("Index", "Home");            
        }
        
        [Authorize]
        public async Task<IActionResult> EditRequest(int Id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                var request = await _context.Requests.FindAsync(Id);
                if (request != null)
                    return View(request);
                return RedirectToAction("ManageRequests");
            }
            return RedirectToAction("Index", "Home");            
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> EditRequest(Request request)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                if (ModelState.IsValid)
                {
                    _context.Requests.Update(request);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("ManageRequests");
                }
                return View(request);
            }
            return RedirectToAction("Index", "Home");            
        }
        [Authorize]
        public async Task<IActionResult> AddAccount()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                ModelAccount account = new ModelAccount();
                return View(account);
            }
            return RedirectToAction("Index", "Home");            
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> AddAccount(ModelAccount account)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                if (ModelState.IsValid)
                {
                    var acc = new Account
                    {
                        FirstName = account.FirstName,
                        Name = account.Name,
                        LastName = account.LastName,
                        UserName = account.UserName,
                        Email = account.Email,
                        PhoneNumber = account.Number,
                        Type = account.Type,
                        Role = account.Role,
                    };
                    var result = await _userManager.CreateAsync(acc, account.Password);
                    if (result.Succeeded)
                    {
                        return RedirectToAction("ManageAccounts");
                    }
                }
                return View(account);
            }
            return RedirectToAction("Index", "Home");            
        }
        [Authorize]
        public async Task<IActionResult> AddQuestion()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                Question question = new Question();
                return View(question);
            }
            return RedirectToAction("Index", "Home");            
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> AddQuestion(Question question)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                if (ModelState.IsValid)
                {
                    _context.Questions.Add(question);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("ManageQuestions");
                }
                return View(question);
            }
            return RedirectToAction("Index", "Home");            
        }
        
        [Authorize]
        public async Task<IActionResult> AddRequest()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                Request request = new Request();
                return View(request);
            }
            return RedirectToAction("Index", "Home");            
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> AddRequest(Request request)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                if (ModelState.IsValid)
                {
                    _context.Requests.Add(request);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("ManageRequests");
                }
                return View(request);
            }
            return RedirectToAction("Index", "Home");            
        }
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteAccount(string id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                var account = await _userManager.FindByIdAsync(id);
                if (account != null)
                {
                    var result = await _userManager.DeleteAsync(account);
                    if (result.Succeeded)
                    {
                        return RedirectToAction("ManageAccounts");
                    }
                }
                else
                {
                    return RedirectToAction("ManageAccounts");
                }
            }
            return RedirectToAction("Index", "Home");
        }
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteQuestion(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                var question = await _context.Questions.FindAsync(id);
                if (question != null)
                {
                    _context.Remove(question);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("ManageQuestions");
                }
                else
                {
                    return RedirectToAction("ManageQuestions");
                }
            }
            return RedirectToAction("Index", "Home");
        }
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteRequest(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null && user.Role == TypeRole.Admin)
            {
                var request = await _context.Requests.FindAsync(id);
                if (request != null)
                {
                    _context.Remove(request);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("ManageRequests");
                }
                else
                {
                    return RedirectToAction("ManageRequests");
                }
            }
            return RedirectToAction("Index", "Home");
        }
    }
}
