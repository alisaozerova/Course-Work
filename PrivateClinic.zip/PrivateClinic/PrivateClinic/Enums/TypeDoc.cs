﻿namespace PrivateClinic.Enums
{
    public enum TypeDoc
    {
        GeneralPractitioner = 1, // Лікар загальної практики
        Cardiologist,        // Кардіолог
        Dermatologist,       // Дерматолог
        Neurologist,         // Невролог
        Pediatrician,        // Педіатр
        Psychiatrist,        // Психіатр
        Surgeon              // Хірург
    }
}
