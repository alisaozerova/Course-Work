﻿namespace PrivateClinic.Enums
{
    public enum TypeRole
    {
        Doctor, // Роль Доктора
        Admin   // Роль Адміністратора
    }
}
